// types/apiTypes.ts
export interface BotReplyResponse {
    text: string;
  }
  